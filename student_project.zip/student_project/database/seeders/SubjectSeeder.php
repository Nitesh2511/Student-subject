<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SubjectSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $subjects = [
            'Mathematics',
            'Science',
            'English',
            'History',
            'Geography',
            'Computer Science',
            'Physics',
            'Chemistry',
            'Biology',
            'Social Studies',
            'Art',
            'Music',
            'Physical Education',
            'Literature',
            'Economics',
            'Business Studies',
            'Psychology',
            'Sociology',
            'Foreign Language',
            'Political Science',
            // Add more subjects as needed
        ];

        foreach ($subjects as $subject) {
            DB::table('subjects')->insert([
                'name' => $subject,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
