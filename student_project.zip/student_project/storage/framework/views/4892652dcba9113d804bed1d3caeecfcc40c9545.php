<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css">
    <title>Create Student</title>
</head>
<body>
    <div class="container">
        <h2>Create Student</h2>
        <form method="POST" action="/students">
            <?php echo csrf_field(); ?> <!-- Laravel CSRF protection token -->
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="age" class="form-label">Age</label>
                <input type="number" class="form-control" id="age" name="age" required>
            </div>
            <div class="mb-3">
                <label for="roll_number" class="form-label">Roll Number</label>
                <input type="text" class="form-control" id="roll_number" name="roll_number" required>
            </div>
            <div class="mb-3">
                <label for="subjects" class="form-label">Subjects</label>
                <select class="form-control" id="subjects" name="subjects[]" multiple required>

                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <!-- Add more subjects as needed -->
                </select>
            </div>
            <!-- Add more fields for other student details if needed -->
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>
    <br>

    <div class="container">
  <h2>Student Table List</h2>       
  <table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Age</th>
        <th>Roll Number</th>
        <th>Subject</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($data['name']); ?></td>
        <td><?php echo e($data['age']); ?></td>
        <td><?php echo e($data['roll_no']); ?></td>
        <td><?php echo e($data['subject']); ?></td>
    </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </tbody>
  </table>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\student_project\resources\views/students/create.blade.php ENDPATH**/ ?>